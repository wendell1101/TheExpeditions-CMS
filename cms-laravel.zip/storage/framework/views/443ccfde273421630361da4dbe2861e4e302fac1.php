

<?php $__env->startSection('title'); ?>
Expeditions | Admin-Tags
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card shadow">
        <div class="card-header">
            <h4><?php echo e($tag->name); ?> - Posts</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <?php if($tag->posts->count() > 0): ?>
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tag->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e(++$loop->index); ?></th>
                            <td><a href="<?php echo e(route('posts.show', $post->slug)); ?>"><?php echo e($post->title); ?></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <?php else: ?>
                    <h2 class="text-secondary text-center">No Post Yet</h2>
                    <?php endif; ?>
                </table>
               
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm');
        form.action = '/tags/' + id + '/delete';
        $('#deleteModal').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/tags/show.blade.php ENDPATH**/ ?>