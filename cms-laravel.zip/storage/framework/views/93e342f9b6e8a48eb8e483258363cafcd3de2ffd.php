

<?php $__env->startSection('title'); ?>
Expeditions | Admin-Tags
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card shadow">
        <div class="card-header d-flex align-items-center">
            <h4>Tags</h4>
            <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-primary ml-auto"><i class="fas fa-plus text-light"></i></a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <?php if($tags->count() > 0): ?>
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">No. of posts</th>

                            <th scope="col">Actions</th>


                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e(++$loop->index); ?></th>
                            <td><a href="<?php echo e(route('tags.show', $tag->slug)); ?>"><?php echo e($tag->name); ?></a></td>
                            <td><?php echo e($tag->posts->count()); ?></td>
                            <td>
                                <a href="<?php echo e(route('tags.edit', $tag->slug)); ?>" class="text-warning mr-3">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <span class="text-danger" onClick="handleDelete(<?php echo e($tag->id); ?>)">
                                    <i class="fas fa-trash"></i>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <?php else: ?>
                    <h2 class="text-secondary text-center">No Tag Yet</h2>
                    <?php endif; ?>
                </table>
                <!-- Modal -->
                <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Delete Tag</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <h3>Are you sure you want to delete this tag?</h3>
                            </div>
                            <div class="modal-footer">
                                <form action="" method="POST" id="deleteForm">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Yes, Delete</button>
                                </form>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function handleDelete(id) {
        let form = document.getElementById('deleteForm');
        form.action = '/tags/' + id + '/delete';
        $('#deleteModal').modal('show');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/tags/index.blade.php ENDPATH**/ ?>