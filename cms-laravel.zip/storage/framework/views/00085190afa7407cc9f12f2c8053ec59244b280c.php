

<?php $__env->startSection('title'); ?>
Expeditions | Admin-Users
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card shadow">
        <div class="card-header">
            <h2>Users</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <?php if($users->count() > 0): ?>
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>


                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-items-center">
                            <th scope="row"><?php echo e(++$loop->index); ?></th>
                            <td>
                                <img src="<?php echo e(Gravatar::get($user->email)); ?>" alt="image" class="shadow rounded-circle" style="width:60px;height:60px">
                            </td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <?php else: ?>
                    <h2 class="text-secondary text-center">No Users Yet</h2>
                    <?php endif; ?>
                </table>

            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/users/index.blade.php ENDPATH**/ ?>