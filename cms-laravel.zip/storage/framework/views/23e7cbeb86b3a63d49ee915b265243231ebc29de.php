

<?php $__env->startSection('title'); ?>
Expeditions | Admin-Posts
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card shadow">
        <div class="card-header d-flex align-items-center">
            <h2>Posts</h2>
            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary ml-auto"><i class="fas fa-plus text-light"></i></a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <?php if($posts->count() > 0): ?>
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Image</th>
                            <th scope="col">Title</th>
                            <th scope="col"></th>


                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e(++$loop->index); ?></th>
                            <td>
                                <img src="<?php echo e(asset('/storage/' . $post->image)); ?>" alt="image" class="shadow" style="width:80px;height:80px">
                            </td>
                            <td><?php echo e($post->title); ?></td>
                            <td class="d-flex">
                                <?php if(!$post->trashed()): ?>
                                <a href="<?php echo e(route('posts.edit', $post->slug)); ?>" class="text-warning mr-3">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <?php else: ?>
                                <form action="<?php echo e(route('post.restore', $post->slug)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit" class="text-primary mr-5" style="border:none">
                                        Restore
                                    </button>
                                </form>
                                <?php endif; ?>
                                <form action="<?php echo e(route('posts.destroy', $post->slug)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <?php if(!$post->trashed()): ?>
                                    <button type="submit" class="btn text-danger btn-sm">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php else: ?>
                                    <button type="submit" class="text-danger" style="border:none">Permanently Delete</button>
                                    <?php endif; ?>
                                    
                                </form>


                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <?php else: ?>
                    <h2 class="text-secondary text-center">No Post Yet</h2>
                    <?php endif; ?>
                </table>

            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>