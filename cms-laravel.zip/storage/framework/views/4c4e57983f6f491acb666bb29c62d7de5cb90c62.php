<div>
    <?php if(session('success')): ?>
        <p class="alert alert-success">
            <?php echo e(session('success')); ?>

        </p>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <p class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </p>
    <?php endif; ?>
</div><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/components/alert.blade.php ENDPATH**/ ?>