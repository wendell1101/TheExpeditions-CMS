

<?php $__env->startSection('title'); ?>
Expeditions | Admin-Tags
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card shadow">
        <div class="card-header">
            <h4><?php echo e(isset($tag) ? 'Update Tag' : 'Create Tag'); ?></h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(isset($tag) ? route('tags.update', $tag->slug) :route('tags.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($tag)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" 
                        value="<?php echo e(isset($tag) ? $tag->name : ''); ?>"
                        class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group d-flex justify-content-end">
                    <a href="<?php echo e(route('tags.index')); ?>" class="btn btn-secondary mr-2">Cancel</a>
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(isset($tag) ? 'Update' : 'Create'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/tags/create.blade.php ENDPATH**/ ?>