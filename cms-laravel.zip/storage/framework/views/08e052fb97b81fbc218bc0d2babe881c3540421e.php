

<?php $__env->startSection('title'); ?>
Expeditions | Admin-Update-Post
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card shadow">
        <a href="<?php echo e(route('categories.show', $post->category->slug)); ?>" 
            class="ml-4 mt-2 text-primary"><i class="fas fa-long-arrow-alt-left" style="font-size:2rem"></i></a>
        <div class="card-header text-center">
            
            <h1><?php echo e($post->title); ?></h1>
            <p>by: <?php echo e($post->user->name); ?></p>
            <p class="font-italic"><?php echo e($post->description); ?></p>
            <div class="image-container text-center" >
                <img src="<?php echo e('/storage/'.$post->image); ?>" class="img-fluid" alt="post_image"style="width:600px">
            </div>
        </div>
        <div class="card-body">
            <p><?php echo $post->content; ?></p>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/posts/show.blade.php ENDPATH**/ ?>