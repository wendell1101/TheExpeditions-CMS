<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>


  <!-- Header -->
  <?php $__env->startSection('header'); ?>
  <header class="header text-center text-white banner">
    <div class="container">

      <div class="row">
        <div class="col-md-8 mx-auto">

          <h1 class="text-light banner-text">Sometimes it's the journey that teaches you a lot about your destination.</h1>
          <p class="lead-2 opacity-90 mt-6 banner-text-sub">Share your fantastic stories to inspire others</p>

        </div>
      </div>

    </div>
  </header><!-- /.header -->
  <?php $__env->stopSection(); ?>

  <!-- Main Content -->
  <?php $__env->startSection('content'); ?>
  <main class="main-content">
    <div class="section bg-gray">
      <div class="container">
        <div class="row">


          <div class="col-md-8 col-xl-9">
            <div class="row gap-y">
              <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-md-6">
                <div class="card border hover-shadow-6 mb-6 d-block">
                  <a href="<?php echo e(route('blog.show', $post->slug)); ?>"><img class="card-img-top" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="Card image cap"></a>
                  <div class="p-6 text-center">
                    <p><a class="small-5 text-lighter text-uppercase ls-2 fw-400" href="<?php echo e(route('blog.category', $post->slug)); ?>"><?php echo e($post->category->name); ?></a></p>
                    <h5 class="mb-0"><a class="text-dark" href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e($post->title); ?></a></h5>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if(request()->query('search')): ?>
                <h2 class="text-muted text-center">No posts found for "<?php echo e(request()->query('search')); ?>"</h2>
                <?php else: ?>
                <h2 class="text-muted text-center">No Post Yet"</h2>
                <?php endif; ?>
              <?php endif; ?>

              <?php echo e($posts->appends(['search' => request()->query('search')])->links()); ?>

            </div>


            
          </div>



          <div class="col-md-4 col-xl-3">
            <div class="sidebar px-4 py-md-0">

              <h6 class="sidebar-title">Search</h6>
              <form class="input-group" action="<?php echo e(route('welcome.index')); ?>" method="GET">
                <input type="text" class="form-control" name="search" placeholder="Search"
                  value="<?php echo e(request()->query('search')); ?>"
                >
                <div class="input-group-addon">
                  <span class="input-group-text"><i class="ti-search"></i></span>
                </div>
              </form>

              <hr>

              <h6 class="sidebar-title">Categories</h6>
              <div class="row link-color-default fs-14 lh-24">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6"><a href="<?php echo e(route('blog.category', $category->slug)); ?>"><?php echo e($category->name); ?></a></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


              </div>

              <hr>

              <!-- <h6 class="sidebar-title">Top posts</h6>
                <a class="media text-default align-items-center mb-5" href="blog-single.html">
                  <img class="rounded w-65px mr-4" src="../assets/img/thumb/4.jpg">
                  <p class="media-body small-2 lh-4 mb-0">Thank to Maryam for joining our team</p>
                </a>

                <a class="media text-default align-items-center mb-5" href="blog-single.html">
                  <img class="rounded w-65px mr-4" src="../assets/img/thumb/3.jpg">
                  <p class="media-body small-2 lh-4 mb-0">Best practices for minimalist design</p>
                </a>

                <a class="media text-default align-items-center mb-5" href="blog-single.html">
                  <img class="rounded w-65px mr-4" src="../assets/img/thumb/5.jpg">
                  <p class="media-body small-2 lh-4 mb-0">New published books for product designers</p>
                </a>

                <a class="media text-default align-items-center mb-5" href="blog-single.html">
                  <img class="rounded w-65px mr-4" src="../assets/img/thumb/2.jpg">
                  <p class="media-body small-2 lh-4 mb-0">Top 5 brilliant content marketing strategies</p>
                </a>

                <hr> -->

              <h6 class="sidebar-title">Tags</h6>
              <div class="gap-multiline-items-1">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="badge badge-secondary" href="<?php echo e(route('blog.tag', $tag->slug)); ?>"><?php echo e($tag->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <hr>

              <h6 class="sidebar-title">About</h6>
              <p class="small-3">TheSaaS is a responsive, professional, and multipurpose SaaS, Software, Startup and WebApp landing template powered by Bootstrap 4. TheSaaS is a powerful and super flexible tool for any kind of landing pages.</p>


            </div>
          </div>

        </div>
      </div>
    </div>
  </main>
  <?php $__env->stopSection(); ?>


</body>

</html>
<?php echo $__env->make('layouts.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wendell1101\Desktop\laravel_projects\cms-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>